package com.showmo.eventBus;

import android.util.Log;

public class EventReciever {//�¼������࣬ͨ��eventBus��register����ע���EventBusɨ��
//	public static interface BackgroundThreadReciever<T extends Event>{
//		  void  onEventBackgroundThread(T ev);
//	}
//	public static interface MainThreadReciever<T extends Event>{
//		 void onEventMainThread(T ev);
//	}
//	public static interface AsyncThreadReciever<T extends Event>{
//		 void onEventAsync(T ev);
//	}
}
