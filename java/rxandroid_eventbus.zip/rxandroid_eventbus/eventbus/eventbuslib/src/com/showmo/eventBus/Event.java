package com.showmo.eventBus;


public class Event {

}
