/** Automatically generated file. DO NOT MODIFY */
package com.example.eventbuslib;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}